# api-docentes-Dm

Proyecto Spring Boot con H2 en memoria que expone una API REST para la entidad `Docente`.

Endpoints principales:
- POST /api/docentes
- GET  /api/docentes
- PUT  /api/docentes/{id}
- DELETE /api/docentes/{id}

H2 console: http://localhost:8080/h2-console (si corres la app)

## Manejo de excepciones
El proyecto contiene un manejador global (`GlobalExceptionHandler`) que devuelve respuestas JSON con estructura:
- timestamp
- status
- error
- message
- details

## Entrega a GitHub
Para subir este proyecto a un repositorio en GitHub, puedes usar estos comandos (desde la raíz del proyecto):

```bash
git init
git add .
git commit -m "Initial commit - API Docentes"
# Crea el repo en GitHub (usa la web o la CLI 'gh'):
# Opción 1: usando la web -> crea un repo vacío llamado api-docentes-Dm
# Opción 2: usando GitHub CLI:
# gh repo create username/api-docentes-Dm --public --source=. --remote=origin --push

# Si ya creaste el repo en la web, añade el remote:
git remote add origin https://github.com/<tu-usuario>/api-docentes-Dm.git
git branch -M main
git push -u origin main
```

### Notas
- La colección Postman está incluida: `postman_collection_api-docentes-Dm.json`
- Hay un workflow de GitHub Actions para compilar con Maven en `.github/workflows/maven.yml`

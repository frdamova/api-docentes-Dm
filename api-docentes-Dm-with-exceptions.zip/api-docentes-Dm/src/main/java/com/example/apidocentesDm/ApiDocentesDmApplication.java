package com.example.apidocentesDm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiDocentesDmApplication {
    public static void main(String[] args) {
        SpringApplication.run(ApiDocentesDmApplication.class, args);
    }
}

package com.example.apidocentesDm.repository;

import com.example.apidocentesDm.model.Docente;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface DocenteRepository extends JpaRepository<Docente, Long> {
    Optional<Docente> findByTipoDocumentoAndNumeroDocumento(String tipoDocumento, String numeroDocumento);
}

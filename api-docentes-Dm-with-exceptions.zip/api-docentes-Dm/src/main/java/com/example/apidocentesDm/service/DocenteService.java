package com.example.apidocentesDm.service;

import com.example.apidocentesDm.exception.ResourceNotFoundException;
import com.example.apidocentesDm.model.Docente;
import com.example.apidocentesDm.repository.DocenteRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class DocenteService {

    private final DocenteRepository repository;

    public DocenteService(DocenteRepository repository) {
        this.repository = repository;
    }

    public Docente crearDocente(Docente docente) {
        boolean existe = repository
                .findByTipoDocumentoAndNumeroDocumento(docente.getTipoDocumento(), docente.getNumeroDocumento())
                .isPresent();
        if (existe) {
            throw new IllegalArgumentException("Ya existe un docente con este tipo y número de documento.");
        }
        return repository.save(docente);
    }

    public List<Docente> obtenerTodos() {
        return repository.findAll();
    }

    public Docente actualizarDocente(Long id, Docente datos) {
        Docente docente = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Docente con id " + id + " no encontrado"));
        // No permitimos actualizar el par tipo+numero a uno ya existente en otro registro
        if (datos.getTipoDocumento() != null && datos.getNumeroDocumento() != null) {
            repository.findByTipoDocumentoAndNumeroDocumento(datos.getTipoDocumento(), datos.getNumeroDocumento())
                    .ifPresent(existing -> {
                        if (!existing.getId().equals(id)) {
                            throw new IllegalArgumentException("Otro docente ya tiene ese tipo y número de documento.");
                        }
                    });
            docente.setTipoDocumento(datos.getTipoDocumento());
            docente.setNumeroDocumento(datos.getNumeroDocumento());
        }

        if (datos.getNombres() != null) docente.setNombres(datos.getNombres());
        if (datos.getApellidos() != null) docente.setApellidos(datos.getApellidos());
        if (datos.getCorreo() != null) docente.setCorreo(datos.getCorreo());
        if (datos.getTelefono() != null) docente.setTelefono(datos.getTelefono());

        return repository.save(docente);
    }

    public void eliminarDocente(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Docente con id " + id + " no encontrado");
        }
        repository.deleteById(id);
    }
}
